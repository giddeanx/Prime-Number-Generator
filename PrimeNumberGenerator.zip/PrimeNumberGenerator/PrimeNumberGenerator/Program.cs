﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

//Created By Dustin Stacey - 8/22/2015
namespace PrimeNumberGenerator
{
    public class PrimeHelper
    {
        public PrimeHelper()
        {
            TestDetermination();
            TestGeneration();
        }

        /// <summary>
        /// Unit test of the prime generator
        /// Input:  Range 7900 - 7920
        /// Required Result : 7901, 7907, 7919
        /// </summary>
        public void TestGeneration()
        {
            const int inputLow = 7900;
            const int inputHigh = 7920;
            var successfulResult = new List<int> {7901, 7907, 7919};
            List<int> procResult = GeneratePrimes(inputLow, inputHigh);
            string result = procResult.Aggregate(string.Empty, (current, prime) => string.Format("{0}{1},", current, prime.ToString()));
            bool success = true;
            foreach (int prime in successfulResult)
            {
                if (!procResult.Exists(g => g == prime))
                {
                    success = false;
                }
                else
                {
                    procResult.Remove(prime);
                }
            }
            if (procResult.Count > 0)
            {
                success = false;
            }
            Debug.Assert(success, "Program Failed to Create the correct List of Primes.",
                         string.Format("The program has failed to produce the test list of primes:  Instead of 7901, 7907, 7919 it produced:{0}", result));
        }

        /// <summary>
        /// Generates Prime Numbers
        /// </summary>
        /// <param name="rangeStart">Start Integer</param>
        /// <param name="rangeEnd">End Integer</param>
        /// <returns></returns>
        public List<int> GeneratePrimes(int rangeStart, int rangeEnd)
        {
            var result = new List<int>();
            for (int i = rangeStart; i <= rangeEnd; i++)
            {
                if (IsPrime(i)) { result.Add(i); }
            }
            return result;
        }

        /// <summary>
        /// Unit test for prime determination 
        /// </summary>
        public void TestDetermination()
        {
            const int testNumberPositive = 7901;
            const int testNumberNegative = 7903;
            const int testOne = 1;

            Debug.Assert(IsPrime(testNumberPositive) && !IsPrime(testNumberNegative) && !IsPrime(testOne), "Program failed to correctly identify a prime.");
        }

        /// <summary>
        /// Determines if a number is prime
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        private bool IsPrime(int number)
        {
            int highRange = Convert.ToInt32(Math.Sqrt(number));
            bool prime = true;
            if (number < 2)
            {
                prime = false;
            }
            else
            {
                for (int i = 2; i <= highRange; i++)
                {
                    if (number % i != 0) continue;
                    prime = false;
                    break;
                }
            }
            return prime;
        }

        
    }

    class Program
    {
        private static void Main(string[] args)
        {
            //Unit Tests
            var helperOfPrime = new PrimeHelper();

            //Bring in Arguments
            var arguments = new List<int>();
            var validArguments = true;
            //pulling integers from arguments
            foreach (var arg in args)
            {
                int parsedArg;
                if (Int32.TryParse(arg, out parsedArg))
                {
                    if (parsedArg >= 0)
                    {
                        arguments.Add(parsedArg);
                    }
                    else
                    {
                        validArguments = false;
                    }
                }
                else
                {
                    validArguments = false;
                }
            }
            //validating argument count
            validArguments = validArguments && (arguments.Count == 2);
            
            if (!validArguments)
            {
                Console.WriteLine(
                    "This program returns all primes between two positive numbers.  Please provide two positive integers in the command line when executing this program.  Ex: PrimeNumberGenerator 5490 5500");
            }
            else
            {
                Console.WriteLine("Prime Numbers:");
                Console.WriteLine(" ");
                var primes = helperOfPrime.GeneratePrimes(arguments.Min(), arguments.Max());
                var output = primes.Aggregate(string.Empty, (current, prime) => string.Format("{0}{1},", current, prime.ToString()));
                Console.WriteLine(output.TrimEnd(','));
            }
        }
    }

}
